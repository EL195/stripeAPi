<html>
  <head><title>Thanks for your order!</title></head>
  <body>
    <h1>Thanks for your order!</h1>
    <p>
      We appreciate your time!
      If you have any questions, please email
      <a href="mailto: gjhwatters@gmail.com">gjhwatters@gmail.com</a><br>
                <a href="index.php">HOME</a>.

    </p>

  </body>
</html>